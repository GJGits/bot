package org.example;

import java.io.IOException;

public interface Job {
    public void init() throws InterruptedException, IOException;
    public void run() throws InterruptedException, IOException;
}
