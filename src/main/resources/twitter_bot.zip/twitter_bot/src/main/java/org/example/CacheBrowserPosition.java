package org.example;

import desktop.Action;
import desktop.Waiter;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

public class CacheBrowserPosition {

    private Point finalPoint;

    private List<Action> goToFinalPoint;

    public CacheBrowserPosition() {
        this.goToFinalPoint = new ArrayList<>();
        this.goToFinalPoint.add(new Waiter(1500));
    }

    public Point getFinalPoint() {
        return this.finalPoint;
    }

    public void addStepToGoToFinalPoint(Action action) {
        this.goToFinalPoint.add(action);
    }

    public void reproduceSteps() throws InterruptedException {
        for (Action a: this.goToFinalPoint) {
            a.act();
        }
    }

    public int size() {
        // la cache presenta sempre un elemento di wait iniziale
        return this.goToFinalPoint.size() - 1;
    }

    public void setFinalPoint(Point coordinatesToReturn) {
        this.finalPoint = coordinatesToReturn;
    }
}
