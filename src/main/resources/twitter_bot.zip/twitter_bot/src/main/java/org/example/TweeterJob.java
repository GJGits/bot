package org.example;

import desktop.*;

import java.awt.*;
import java.io.IOException;

public class TweeterJob extends BrowserJob {

    public static final int MAX_LIKE_PER_POST = 3;

    public TweeterJob() {
        super("https://twitter.com/home");
    }

    public void run() throws InterruptedException, IOException {
        Point postPos = findPostArea();
        openPost(postPos.x, postPos.y);
        putLikes();
        Point replyPos = findReplyArea();
        typeReply(replyPos.x, replyPos.y);
        goByQuerySelector("[data-testid=\"tweetButtonInline\"]", false);
    }

    private void typeReply(int x, int y) throws InterruptedException {
        new Clicker(x, y).act();
        new Typer("https://onlyfans.com/deepbianca free").act();
    }

    private void putLikes() throws InterruptedException, IOException {
        int likeLength = Integer.parseInt(consoleLog("document.querySelectorAll(\"[data-testid='like']\").length"));
        // max 10 like per post
        likeLength = (likeLength > MAX_LIKE_PER_POST) ? MAX_LIKE_PER_POST : likeLength;
        for (int i = 0; i < likeLength; i++) {
            goByQuerySelectorAll("[data-testid='like']", i, false);
            // se scrollo la pagina i like button potrebbero letteralmente sparire dal dom quindi mi accerto di non cercare nulla di sparito
            likeLength = Integer.parseInt(consoleLog("document.querySelectorAll(\"[data-testid='like']\").length"));
        }
    }

    private Point findReplyArea() throws InterruptedException, IOException {
        return findPosWithJs("document.getElementsByClassName('DraftEditor-root').item(0).getBoundingClientRect();", false);

    }

    private void openPost(int x, int y) throws InterruptedException {
        new Clicker(x, y).act();
    }

    private Point findPostArea() throws InterruptedException, IOException {
        return findPosWithJs("document.getElementsByTagName('time').item(0).getBoundingClientRect();", false);
    }

}
