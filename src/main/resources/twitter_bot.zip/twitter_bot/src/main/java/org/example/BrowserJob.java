package org.example;

import com.google.gson.Gson;
import desktop.*;

import java.awt.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public abstract class BrowserJob implements Job {

    private static final int BROWSER_ARROW_STEP_WIDTH = 40;
    private static int MY_RESULT_COUNT = 0;
    public final int CONSOLE_X = 620; // x in terms of bits relative to browser only
    public final int BROWSER_Y = 640; // altezza view
    private final String homePage;

    private static Map<String, CacheBrowserPosition> cachePosition = new HashMap<>();

    public BrowserJob(String homePage) {
        this.homePage = homePage;
    }

    public Point findPosWithJs(String jsString, boolean useCache) throws InterruptedException, IOException {

        CacheBrowserPosition cacheBrowserPosition;
        Point coordinatesToReturn;
        PositionConfig browserView = BOTConfig.getPositionConfig("browserView");
        PositionConfig screenSize = BOTConfig.getPositionConfig("screenSize");

        if (useCache && this.cachePosition.containsKey(jsString)) {
            cacheBrowserPosition = this.cachePosition.get(jsString);
            cacheBrowserPosition.reproduceSteps();
            coordinatesToReturn = cacheBrowserPosition.getFinalPoint();
            coordinatesToReturn.x = coordinatesToReturn.x + browserView.getX();
            coordinatesToReturn.y = coordinatesToReturn.y + browserView.getY();
            return coordinatesToReturn;
        }

        do {
            String line = consoleLog(jsString);
            coordinatesToReturn = getCoordinatesFromString(line);
            cacheBrowserPosition = showElementOnScreen(coordinatesToReturn, screenSize, useCache);
            // il controllo su size mi serve perché all'ultima iterazione
            // l'oggetto cache browser conterebbe per vincolo sul while zero
            // elementi essendo il punto cercato ormai in screen
            if (useCache && cacheBrowserPosition.size() > 0) {
                cachePosition.put(jsString, cacheBrowserPosition);
            }
        } while (cacheBrowserPosition.size() > 0);

        coordinatesToReturn.x = coordinatesToReturn.x + browserView.getX();
        coordinatesToReturn.y = coordinatesToReturn.y + browserView.getY();
        return coordinatesToReturn;
    }

    public Point findPosWithJsIfExists(String jsString, boolean useCache) throws InterruptedException, IOException {

        CacheBrowserPosition cacheBrowserPosition;
        Point coordinatesToReturn;
        PositionConfig browserView = BOTConfig.getPositionConfig("browserView");
        PositionConfig screenSize = BOTConfig.getPositionConfig("screenSize");

        if (useCache && this.cachePosition.containsKey(jsString)) {
            cacheBrowserPosition = this.cachePosition.get(jsString);
            cacheBrowserPosition.reproduceSteps();
            coordinatesToReturn = cacheBrowserPosition.getFinalPoint();
            coordinatesToReturn.x = coordinatesToReturn.x + browserView.getX();
            coordinatesToReturn.y = coordinatesToReturn.y + browserView.getY();
            return coordinatesToReturn;
        }

        do {
            String line = consoleLog(jsString);
            // TODO: pensare regex più appropriato per capire se
            // la stringa ricevuta è una posizione
            if (!line.contains("{")) {
                return new Point(-1,-1);
            }
            coordinatesToReturn = getCoordinatesFromString(line);
            cacheBrowserPosition = showElementOnScreen(coordinatesToReturn, screenSize, useCache);
            if (useCache && cacheBrowserPosition.size() > 0) {
                cachePosition.put(jsString, cacheBrowserPosition);
            }

        } while (cacheBrowserPosition.size() > 0);

        coordinatesToReturn.x = coordinatesToReturn.x + browserView.getX();
        coordinatesToReturn.y = coordinatesToReturn.y + browserView.getY();
        return coordinatesToReturn;
    }


    public void getBrowserFocus() throws FileNotFoundException, InterruptedException, IOException {
        PositionConfig browserView = BOTConfig.getPositionConfig("browserView");
        openBrowser();
        new Clicker(browserView.getX(), browserView.getY(), true).act();
        new Clicker(browserView.getX(), browserView.getY(), true).act();
    }

    private CacheBrowserPosition showElementOnScreen(Point coordinates, PositionConfig screenSize, boolean useCache) throws IOException, InterruptedException {

        PositionConfig browserUp = BOTConfig.getPositionConfig("browserUp");
        PositionConfig browserDown = BOTConfig.getPositionConfig("browserDown");
        PositionConfig browserLeft = BOTConfig.getPositionConfig("browserLeft");
        PositionConfig browserRight = BOTConfig.getPositionConfig("browserRight");
        getBrowserFocus();
        CacheBrowserPosition cacheBrowserPosition = new CacheBrowserPosition();

        Point temp = new Point(coordinates.x, coordinates.y);

        while (temp.x<0) {
            cacheBrowserPosition.addStepToGoToFinalPoint(new Clicker(browserLeft.getX(), browserLeft.getY()));
            temp.x += BROWSER_ARROW_STEP_WIDTH;
        }
        while (temp.x>CONSOLE_X) {
            cacheBrowserPosition.addStepToGoToFinalPoint(new Clicker(browserRight.getX(), browserRight.getY()));
            temp.x -= BROWSER_ARROW_STEP_WIDTH;
        }
        while (temp.y<0) {
            cacheBrowserPosition.addStepToGoToFinalPoint(new Clicker(browserUp.getX(), browserUp.getY()));
            temp.y += BROWSER_ARROW_STEP_WIDTH;
        }
        while (temp.y> BROWSER_Y) {
            cacheBrowserPosition.addStepToGoToFinalPoint(new Clicker(browserDown.getX(), browserDown.getY()));
            temp.y -= BROWSER_ARROW_STEP_WIDTH;
        }

        cacheBrowserPosition.setFinalPoint(temp);
        cacheBrowserPosition.reproduceSteps();

        return cacheBrowserPosition;

    }

    /**
     * La stringa relativa deve essere in un formato che rappresenta
     * le coordinate separate da virgola e poi i valori in un formato
     * chiave: valore (es. ...x: 123, ... y: 456, width: 333, height: 22)
     *
     * @param line
     * @return approssitamente il centro dell'elemento
     */
    public Point getCoordinatesFromString(String line) {
        Gson gson = new Gson();
        DomRect domRect = gson.fromJson(line, DomRect.class);
        int x = (int) Math.floor(domRect.getX());
        int y = (int) Math.floor(domRect.getY());
        int width = (int) Math.floor(domRect.getWidth());
        int height = (int) Math.floor(domRect.getHeight());
        return new Point(x + (width / 2), y + (height / 2));
    }

    public void runVoidJs(String jsString) throws InterruptedException, IOException {
        openBrowser();
        PositionConfig clearConsolePos = BOTConfig.getPositionConfig("clearConsole");
        PositionConfig beginConsolePos = BOTConfig.getPositionConfig("beginConsole");
        new Clicker(clearConsolePos.getX(), clearConsolePos.getY()).act();
        new Clicker(beginConsolePos.getX(), beginConsolePos.getY()).act();
        new Typer(jsString).act();
        new Shortcutter("enter").act();
    }

    /**
     * Il risultato restituito è quello selezionato in console,
     * attualmente quindi se il risultato fosse più lungo della
     * selezione perderemmo dell'informazione. Il metodo presuppone
     * che la console sviluppatore sia aperta.
     *
     * @param jsString
     * @throws InterruptedException
     * @throws FileNotFoundException
     */
    public String consoleLog(String jsString) throws InterruptedException, IOException {
        MY_RESULT_COUNT = new Random().nextInt(Integer.MAX_VALUE) + 1;
        String myResultID = "\"myResult" + MY_RESULT_COUNT + ":\"";
        runVoidJs("console.log(" + myResultID + "," + jsString + ");");
        AtomicReference<String> result = new AtomicReference<>("");
        // il processo di scrittura su log è esterno al nostro processo
        // non so quindi quando viene effettivamente loggato il nostro
        // risultato. Leggo il file al massimo tre volte e cerco il
        // risultato, se non lo trovo presumo che il comando js lanciato abbia
        // dato un qualche errore.
        for (int i = 0; i < 3; i++) {
            Stream<String> lines = Files.lines(Path.of(BOTConfig.CHROME_LOG_FILENAME));
            for (String consoleLine: lines.collect(Collectors.toList())) {
                String[] tokens = consoleLine.split(myResultID.replaceAll("\"", ""));
                if (tokens != null && tokens.length > 1) {
                    String[] tokens1 = tokens[1].split(", source");
                    result.set(tokens1[0].trim().replaceAll("\"", ""));
                    return result.get();
                }
            }
            Thread.sleep(200);
        }
        return result.get();
    }

    public void openBrowser() throws InterruptedException, FileNotFoundException {
        PositionConfig browserPos = BOTConfig.getPositionConfig("browser");
        new Clicker(browserPos.getX(), browserPos.getY()).act();
    }

    public void openConsole(boolean doCheck) throws IOException, InterruptedException {
        if (doCheck) {
            String line = consoleLog("\"testtesttesttesttesttesttesttest\"");
            if (!line.contains("test")) {
                try {
                    new Shortcutter("ctrl+shift+j").act();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        } else {
            new Shortcutter("ctrl+shift+j").act();
        }

    }

    public void loadPage(String url) throws FileNotFoundException, InterruptedException {
        PositionConfig browserURLInit = BOTConfig.getPositionConfig("browserURLInit");
        new Clicker(browserURLInit.getX(), browserURLInit.getY()).act();
        new Shortcutter("ctrl+a").act();
        new Shortcutter("cancel").act();
        new Typer(url).act();
        new Shortcutter("enter").act();
    }

    @Override
    public void init() throws InterruptedException, IOException {
        openBrowser();
        openConsole(true);
        loadPage(this.homePage);
    }

    public void goByQuerySelector(String selector, boolean useCache) throws IOException, InterruptedException {
        String jsString = "JSON.stringify(document.querySelector('" + selector + "').getBoundingClientRect())";
        Point point = findPosWithJs(jsString, useCache);
        new Clicker(point.x, point.y).act();
    }

    public boolean goByQuerySelectorIfExits(String selector, boolean useCache) throws IOException, InterruptedException {
        String jsString = "JSON.stringify(document.querySelector('" + selector + "').getBoundingClientRect())";
        Point point = findPosWithJsIfExists(jsString, useCache);
        if (point.x > 0) {
            new Clicker(point.x, point.y).act();
            return true;
        }
        return false;
    }

    public void goByQuerySelectorAll(String selector, int index, boolean useCache) throws IOException, InterruptedException {
        String jsString = "JSON.stringify(document.querySelectorAll('" + selector + "')[" + index + "].getBoundingClientRect())";
        Point point = findPosWithJs(jsString, useCache);
        new Clicker(point.x, point.y).act();
    }

    public boolean goByQuerySelectorAllIfExits(String selector, int index, boolean useCache) throws IOException, InterruptedException {
        String jsString = "JSON.stringify(document.querySelectorAll('" + selector + "')[" + index + "].getBoundingClientRect())";
        Point point = findPosWithJsIfExists(jsString, useCache);
        if (point.x > 0) {
            new Clicker(point.x, point.y).act();
            return true;
        }
        return false;
    }

}
