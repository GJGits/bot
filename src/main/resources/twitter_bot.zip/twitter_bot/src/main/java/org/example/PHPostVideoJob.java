package org.example;

import desktop.*;

import java.awt.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class PHPostVideoJob extends BrowserJob {

    private static final int NUM_OF_PAGES = 5;
    private static final String USERNAME_FILENAME = "phUsernames.txt";
    private static Set<String> alreadyProcessedUsers = new HashSet<>();

    public PHPostVideoJob() {
        super("https://it.pornhub.com/");
    }

    @Override
    public void init() throws InterruptedException, IOException {
        loadUsernames();
        super.init();
        clickOnCommunity();
        clickRicercaAvanzata();
        doSearch();
    }

    private void loadUsernames() throws IOException {
        // Create a Path object representing the file
        Path filePath = Path.of(BOTConfig.getBotPath() + "/" + USERNAME_FILENAME);
        // Open the file for appending using try-with-resources
        // Read all lines from the file
        var lines = Files.readAllLines(filePath);

        // Process each line
        for (String line : lines) {
            String[] usernames = line.split(";");
            for (String username : usernames) {
                alreadyProcessedUsers.add(username.replaceAll("\"", ""));
            }
        }
    }

    @Override
    public void run() throws InterruptedException, IOException {
        for (int i = 0; i < NUM_OF_PAGES; i++) {
            goToNextPage(0);
            int numOfUsers = getNumberOfUsers();
            for (int j = 0; j < numOfUsers; j++) {
                String userName = consoleLog("document.querySelectorAll('.search-results .usernameBadgesWrapper > a')[" + j + "].innerText");
                if (!alreadyProcessedUsers.contains(userName)) {
                    alreadyProcessedUsers.add(userName);
                    addUserToFile(userName);
                    // Un utente potrebbe banalmente non avere una
                    // bacheca pubblica o sulla quale è possibile
                    // postare un video. Non voglio fermarmi in questi
                    // casi. Mi blocco tuttavia al primo utente con esito positivo
                    try {
                        boolean posted = postOnUserStream(j);
                        if (posted) {
                            return;
                        }
                    } finally {
                        // evito che si aprino finestre all'infinito
                        closeSecondTab();
                    }

                }
            }
        }

    }

    private void addUserToFile(String username) throws IOException {
        // Create a Path object representing the file
        Path file = Path.of(BOTConfig.getBotPath() + "/" + USERNAME_FILENAME);

        // Open the file for appending using try-with-resources
        try (var writer = Files.newBufferedWriter(file, StandardOpenOption.APPEND)) {
            // Append content to the file
            writer.write(username + ";");
        }
    }

    private void goToNextPage(int i) throws IOException, InterruptedException {
        goByQuerySelectorAll(".page_number", i, false);
    }

    private boolean postOnUserStream(int j) throws IOException, InterruptedException {
        openUserPageOnAnotherTab(j);
        goToSecondTab();
        // open user stream
        goByQuerySelector("#profileStream", false);
        boolean possibilePostare = goByQuerySelectorIfExits("#postStreamText", false);
        if (possibilePostare) {
            boolean videoOptExists = goByQuerySelectorAllIfExits(".videos > div", 2, false);
            if (videoOptExists) {
                int vidToShow = new Random().nextInt(0,4);
                goByQuerySelectorAll(".attacherImgBlock", vidToShow, false);
                goByQuerySelector("#caption", false);
                new Typer("Hi come and check out my OF page: https://onlyfans.com/deepbianca").act();
                goByQuerySelector("#postToStream", false);
                new Waiter(2000).act();
                return true;
            }
        }
        return false;
    }

    private void openUserPageOnAnotherTab(int j) throws InterruptedException, IOException {
        String jsString = "JSON.stringify(document.querySelectorAll('.search-results > li')[" + j + "].getBoundingClientRect())";
        Point userImgPos = findPosWithJs(jsString, true);
        new Positioner(userImgPos.x, userImgPos.y).act();
        new Shortcutter("ctrl+sx").act();
    }

    private static void closeSecondTab() throws FileNotFoundException, InterruptedException {
        PositionConfig closeSecondTab = BOTConfig.getPositionConfig("closeSecondTab");
        new Clicker(closeSecondTab.getX(), closeSecondTab.getY()).act();
    }

    private void goToSecondTab() throws InterruptedException, IOException {
        PositionConfig secondTab = BOTConfig.getPositionConfig("secondTab");
        new Clicker(secondTab.getX(), secondTab.getY()).act();
        openConsole(false);
    }

    private int getNumberOfUsers() throws IOException, InterruptedException {
        String lenStr = consoleLog("document.querySelectorAll('.userWidgetWrapperGrid.search-results > li').length");
        return Integer.parseInt(lenStr);
    }

    private void doSearch() throws IOException, InterruptedException {
        goByQuerySelector("[for=\"isOnline\"]>span", false);
        runVoidJs("document.getElementById('formInterestedIn').value = 2;");
        runVoidJs("document.querySelector('[value=\"Cerca\"]').focus();");
        goByQuerySelector("[value=\"Cerca\"]", false);
    }

    private void clickRicercaAvanzata() throws IOException, InterruptedException {
        goByQuerySelectorAll("#coummunityMenuItems>li", 4, false);
    }

    private void clickOnCommunity() throws IOException, InterruptedException {
        goByQuerySelector("#menuItem7", false);
    }
}
