package org.example;


import java.io.*;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

/**
 * Prerequisiti aprire Chrome su pagina twittwer con finestra
 * devtool posizionata sulla destra e una dimensione di:
 * 630 (relativo a browser, 690 considerando la screen size)
 * x altezza schermo (la larghezza è pensata per far stare
 * qualsiasi istruzione js su una riga altrimenti fallirebbe
 * il copia incolla)
 */
public class App {

    private static final int WAIT_TIME_BETWEEN_JOBS = 10000;
    private static int total;
    private static int oks;
    private static int runId;
    private static final Random random = new Random();

    public static void main(String[] args) throws IOException, InterruptedException {
        if (args != null && args.length == 1) {

            BOTConfig.setBotPath(args[0]);
            Job job = new TweeterJob();
            runId = random.nextInt(Integer.MAX_VALUE) + 1;
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            LogUtility.log(String.format("Start job %s (runID = %d)", job, runId));
            for (int i = 0; i < 2; i++) {
                // le eccezioni di tipo InterruptedException o
                // FileNotFoundException sono da considerare fatali
                // infatti queste vengono lanciate in caso uno dei
                // file non fosse presente o il java.awt.Robot avesse
                // dei problemi con il sistema operativo. In questi
                // casi non avrebbe senso continuare. In caso contrario
                // si continua a tentare di eseguire un altro job loggando
                // eventualmente il problema riscontrato
                try {
                    job.init();
                    job.run();
                    oks++;
                } catch (InterruptedException | FileNotFoundException e) {
                    throw new RuntimeException(e.getMessage());
                } catch (Exception e) {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    String exceptionAsString = sw.toString();
                    LogUtility.log(String.format("[runId = %d, %s], error message: %s", runId, dtf.format(now), exceptionAsString));
                } finally {
                    total++;
                    Thread.sleep(WAIT_TIME_BETWEEN_JOBS);
                }

            }
            LocalDateTime finish = LocalDateTime.now();
            Duration duration = Duration.between(now, finish);
            // Format the duration as hh:mm:ss
            long hours = duration.toHours();
            long minutes = duration.toMinutesPart();
            long seconds = duration.toSecondsPart();
            LogUtility.log(String.format("[runID = %d, %s elapse time (%02d:%02d:%02d)], Total: %d, ok: %d", runId, dtf.format(now), hours, minutes, seconds, total, oks));
            LogUtility.log("#####");
        }
    }

}
